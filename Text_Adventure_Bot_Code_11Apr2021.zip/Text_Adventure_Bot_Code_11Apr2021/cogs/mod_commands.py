import discord
import random
from discord.ext import commands

#Cog for the mod commands the bot can run
class mod_commands(commands.Cog):

    def __init__(self, bot):
        self.bot = bot
    
    #Purges messages from the chat channel, defaults to 10 messages
    @commands.command()
    #@commands.has_permissions(manage_messages=True)
    async def clear(self, ctx, amount = 10):
        await ctx.channel.purge(limit=amount)

    #Purges 999 messages from the chat channel
    @commands.command()
    @commands.has_permissions(manage_messages=True)
    async def bulk_clear(self, ctx, amount = 999):
        await ctx.channel.purge(limit=amount)
    

    #Creates spam for testing purposes
    @commands.command()
    #@commands.has_permissions(manage_messages=True)
    async def spam(self, ctx):
        for i in range(5):
            await ctx.channel.send(i+1)
    

def setup(client):
    client.add_cog(mod_commands(client))