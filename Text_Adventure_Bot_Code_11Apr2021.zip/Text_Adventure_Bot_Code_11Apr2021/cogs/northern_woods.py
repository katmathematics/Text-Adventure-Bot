import random
import json

import discord
from discord.ext import tasks, commands
from discord.utils import get
from discord.ext.commands import Cog, BucketType
from discord import Embed, Member

class northern_woods(commands.Cog):

    #Init fucntion for northern woods cog
    def __init__(self, bot):
        self.bot = bot

    #Grabs a random prompt header which is used to dictate all the pieces of a prompt
    def get_rand_prompt():
        return random.choice(prompts)

    #Custom check to restrict command use
    def in_channel(*channels):
        def predicate(ctx):
            return ctx.channel.id in channels
        return commands.check(predicate)

    #Channel ID for the northern calyx woods
    north_woods = 830239804674539571

    #Terms for the universal commands - these serve as alternate aliases so the commonly used commands can be more easily guessed.
    common_attack_commands = ["attack", "punch", "kick", "shoot", "stab", "slice", "impale"]
    common_search_commands = ["investigate", "search", "look", "stare", "check"]
    common_give_commands = ["give","lend","hand","offer"]
    common_aid_commands = ["assist","aid","anti-attack"]
    common_talk_commands = ["talk", "chat", "bother", "parley", "speak"]
    common_munch_commands = ["bite", "taste", "munch", "nom", "swallow"]
    common_go_commands = ["go", "move", "leave", "exit", "walk", "run", "jog", "swagger", "dance", "prance", "cartwheel", "saunter", "wander", "trot"]

    #Reads in the set file
    with open("cogs/prompts/northern_woods_sets.json", "r") as setsFile:
        data = setsFile.read()

    #makes settings global so the functions can access it with ease
    global settings

    #Parse json
    settings = json.loads(data)

    #makes the actions global
    global prompts, p_header, description, actors, actions
    prompts = []
    actors = []
    actions = []

    #Grabs the prompt headers from the settings
    for prompt in settings:
        prompts.append(prompt)
    
    #Gets an initial prompt header for the channel
    p_header = get_rand_prompt()

    #Grabs the description associated with the header
    description = settings[p_header]['Description']

    #Grabs the actors for the associated header
    for actor in settings[p_header]['Actors']:
        actors.append(actor)

    #Grabs the available custom actions for the associated header
    for action in settings[p_header]['Commands']:
        actions.append(action)
        
    #Refreshes the prompt available in the channel
    @in_channel(north_woods)
    @commands.cooldown(1, 60, BucketType.user)
    @commands.command()
    async def event(self, ctx):
        global settings, p_header, description, actors, actions
        #Picks a new random prompt
        p_header = northern_woods.get_rand_prompt()
        #Resets the description
        description = settings[p_header]['Description']
        #Clears the actors list and refills it with actors for the new scene
        actors = []
        for actor in settings[p_header]['Actors']:
            actors.append(actor)
        #Clears the actions list and reffils it with actions for the new scene
        actions = []
        for action in settings[p_header]['Commands']:
            actions.append(action)
        #Sends a message containing the header of the new prompt
        await ctx.send(f'New Prompt: {p_header}')
        await ctx.send(f'Description: {description}')
    
    #Repeats the info about the current prompt any user could have access to
    @in_channel(north_woods)
    @commands.command()
    async def check_event(self, ctx):
        await ctx.send(f'New Prompt: {p_header}')
        await ctx.send(f'Description: {description}')

    #Check all the details of the current prompt
    @in_channel(north_woods)
    @commands.has_permissions(manage_channels=True)
    @commands.command()
    async def check_prompt(self, ctx):
        await ctx.send(f'Title: {p_header}')
        await ctx.send(f'Description: {description}')
        await ctx.send(f'Actors: {actors}')
        await ctx.send(f'Actions: {actions}')

    #Refresh command for moderators
    @in_channel(north_woods)
    @commands.has_permissions(manage_channels=True)
    @commands.command()
    async def reroll_nw(self, ctx):
        global settings, p_header, description, actors, actions
        #Picks a new random prompt
        p_header = northern_woods.get_rand_prompt()
        #Resets the description
        description = settings[p_header]['Description']
        #Clears the actors list and refills it with actors for the new scene
        actors = []
        for actor in settings[p_header]['Actors']:
            actors.append(actor)
        #Clears the actions list and reffils it with actions for the new scene
        actions = []
        for action in settings[p_header]['Commands']:
            actions.append(action)
        #Sends a message containing the header of the new prompt
        await ctx.send(f'New Prompt: {p_header}')
        await ctx.send(f'Description: {description}')


    #-----------------------------------------------------------------------
    #            Everything from this point down is action code
    #                   Actions take up a lot of space
    #-----------------------------------------------------------------------

    #----------Action template---------
    #
    # Loop through all actors/objects in the actors list
    #for actor in actors:
    ######## If the user provided arg is found to match with one of the actors, go through the nested if to see if it has an special associated dialog
    #       if actor == args:
    ############ If the matching actor was a "box", print the special dialog for box (note: every command has a 'box' response, as box is the default object in the demo env)            
    #           if actor == "box":
    #               await ctx.send("You talk to the box. It seems less lonely than before.")
    ############ If no special dialog could be found for a known actor/object, tell the user their request was silly, then return
    #           else:
    #               await ctx.send("You try to talk, only realize what you're trying to talk to is silly.")
    #           return
    #### If no actor match could be found, tell the user the object they wanted to interact with couldn't be found.
    #   await ctx.send("You attempt to talk, only realize you can't find what you were trying to talk to")
    #
    #----------------------------------

    #The Attack Action
    @in_channel(north_woods)
    @commands.command(aliases = common_attack_commands)
    async def nw_attacks(self, ctx, args):
        for actor in actors:
            if actor == args:
                if actor == "box":
                    await ctx.send("You attack the box. It crumples a little in defeat.")
                elif actor == "crow":
                    await ctx.send("You attempt to attack the crow. It caws angrily before flying away.")
                    actors.remove("crow")
                elif actor == "salesman":
                    await ctx.send("You attack the salesman. He speeds up his cart and flees northwards.")
                    actors.remove("salesman")
                    actors.remove("oxen")
                    actors.remove("cart")
                elif actor == "oxen":
                    await ctx.send("You attack the oxen, startling them and causing them to bolt north, dragging the cart and salesman with")
                    actors.remove("salesman")
                    actors.remove("oxen")
                    actors.remove("cart")
                elif actor == "pixie":
                    await ctx.send("You attack the helpless pixie, slaying them instantly.")
                    actors.remove("pixie")
                elif actor == "mushrooms":
                    await ctx.send("You attack the mushrooms. Though why you'd attack such fungis is unclear.")
                    actor.remove("mushrooms")
                elif (actor == "bush" or actor == "rustling") and ("rustling" in actors):
                    await ctx.send("You attack the source of the rustling. A little pixie flutters out. They look dazed and annoyed.")
                    actors.remove("rustling")
                elif (actor == "bush") and not ("rustling" in actors):
                    await ctx.send("You attack the bush, but alas, there's nothing else in it.")
                else:
                    await ctx.send("You prepare to attack, only to realize what you're trying to do is silly.")
                return
        await ctx.send("You prepare to attack, only to realize you can't find what you were targeting.")


    #The Search Command
    @in_channel(north_woods)
    @commands.command(aliases = common_search_commands)
    async def nw_searches(self, ctx, args):
        for actor in actors:
            if actor == args:
                if actor == "box":
                    await ctx.send("You search the box. It's made of a plain cardboard. There's nothing inside")
                elif actor == "cart":
                    await ctx.send("You search the salesman's cart. He seems to be short on goods at the moment, only a lantern, a cookie, and a rock are for sale.")
                elif actor == "trees":
                    await ctx.send("You search the trees. Unfortunately the woods get dense quickly. Not wanting to get lost you return to the path.")
                elif actor == "leaves":
                    await ctx.send("You search the scattered leaves. There's nothing unusual about them.")
                elif actor == "north":
                    await ctx.send("You search the north. In the distance you can kinda make out the tip of a church spire and some gently rising smoke, presumably coming from a chimney.")
                elif actor == "south":
                    await ctx.send("You search the south. While the path is still relatively good, it gets sligtly more ominous the further you look.")
                else:
                    await ctx.send("You try to search, only to realize what you're trying to search is silly.")
                return
        await ctx.send("You attempt to search, only to realize you can't find what you intended to find.")
    
    #The Help Command
    @in_channel(north_woods)
    @commands.command(aliases = common_aid_commands)
    async def nw_aids(self, ctx, args):
        for actor in actors:
            if actor == args:
                if actor == "box":
                    await ctx.send("You aid the box by smoothing out it's creases. It seems grateful somehow.")
                elif actor == "pixie":
                    await ctx.send("You offer the pixie your hand to rest on while they reorient themself. They seem grateful.")
                else:
                    await ctx.send("You try to aid, only to realize what you're trying to aid is silly.")
                return
        await ctx.send("You attempt to aid, only to realize you can't find what you were trying to aid")


    #The Talk Command
    @in_channel(north_woods)
    @commands.command(aliases = common_talk_commands)
    async def nw_talks(self, ctx, args):
        for actor in actors:
            if actor == args:
                if actor == "box":
                    await ctx.send("You talk to the box. It seems less lonely than before.")
                elif actor == "crow":
                    await ctx.send("You try shouting \'Nevermore\' at the crow to see if you get a response. While you don't know it, the crow loses 1 point of respect towards you for implying it's a raven.")
                else:
                    await ctx.send("You try to talk, only to realize what you're trying to talk to is silly.")
                return
        await ctx.send("You attempt to talk, only to realize you can't find what you were trying to talk to")

    #The Munch Command
    @in_channel(north_woods)
    @commands.command(aliases = common_munch_commands)
    async def nw_munches(self, ctx, args):
        for actor in actors:
            if actor == args:
                if actor == "box":
                    await ctx.send("You attempt to eat the box. It's taste reminds you of Chuck E. Cheese pizza.")
                elif actor == "mushrooms":
                    await ctx.send("You eat the random mushrooms. That was probably a smart idea.")
                    actors.remove("mushrooms")
                else:
                    await ctx.send("You try to eat, only to realize what you're trying to eat is silly.")
                return
        await ctx.send("You attempt to eat, only to realize you can't find what you were trying to eat")


    #The Go Command
    @in_channel(north_woods)
    @commands.command(aliases = common_go_commands)
    async def nw_goes(self, ctx, args):
        for actor in actors:
            if actor == args:
                if actor == "box":
                    await ctx.send("You go to the box. You were already at the box. But now you are more at the box")
                else:
                    await ctx.send("You try to go, only to realize where you're trying to go is silly")
                return
            await ctx.send("You attempt to go, only to realize you can't find where you wanted to go")


    ################Commands custom to the North Woods#########################
    @in_channel(north_woods)
    @commands.command()
    async def follow(self, ctx, args):
            for actor in actors:
                if actor == args:
                    if actor == "box":
                        await ctx.send("You follow the box. It's not going anywhere but you follow it nonetheless.")
                    elif actor == "pixie":
                        await ctx.send("You decide to follow the pixie. They flitter off deeper into the woods, and it quickly becomes difficult to keep pace. Just as you think you've lost them, you see a clearing with a sparkling, clear pond. It's beautiful. You're happy you made the trek.")
                    elif actor == "crow":
                        await ctx.send("You decide to follow the crow. It flaps off deeper into the woods, and it quickly becomes difficult to keep pace. Just as you think you've lost it, you see a clearing with a sparkling, clear pond. It's beautiful. You're happy you made the trek.")
                    else:
                        await ctx.send("You start following, only to realize what you're trying to follow is silly.")
                    return
            await ctx.send("You try to follow, only to realize you can't find what you wanted to follow.")

    @in_channel(north_woods)
    @commands.command()
    async def scare(self, ctx, args):
        for actor in actors:
            if actor == args:
                if actor == "box":
                    await ctx.send("You scare the box. It defiantly remains motionless on the floor.")
                elif actor == "crow":
                    await ctx.send("You scare the crow away, it caws in annoyance before beginning to fly away")
                else:
                    await ctx.send("You try to scare something, only to realize what you're trying to scare is silly.")
                return
        await ctx.send("You try to scare something, only to realize you can't find what you wanted to scare.")

    @in_channel(north_woods)
    @commands.command()
    async def feed(self, ctx, args):
        for actor in actors:
            if actor == args:
                if actor == "box":
                    await ctx.send("You feed the box a cookie. There is now a cookie inside the box.")
                elif actor == "crow":
                    await ctx.send("You feed the crow a cookie, it caws in happily.")
                elif actor == "pixie":
                    await ctx.send("You feed the pixie a cookie, it sparkles in happily.")
                elif actor == "oxen":
                    await ctx.send("You feed the oxen a cookie, it moos in happily.")
                elif actor == "salesman":
                    await ctx.send("You give the salesman a cookie. You've really brightened his day.")
                else:
                    await ctx.send("You try to feed something, only to realize what you're trying to feed is silly.")
                return
        await ctx.send("You try to feed something, only to realize you can't find what you wanted to feed.")
            
    @in_channel(north_woods)
    @commands.command()
    async def pet(self, ctx, args):
        for actor in actors:
            if actor == args:
                if actor == "box":
                    await ctx.send("You pet the box. It seems happy for the affection.")
                elif actor == "crow":
                    await ctx.send("You attempt to pet the crow. It hesitates but ultimately lets you pet it.")
                elif actor == "pixie":
                    await ctx.send("You attempt to pet the pixie. They give an annoyed shake and start to flutter off.")
                elif actor == "oxen":
                    await ctx.send("You attempt to pet the oxen. It moos happily at the affection.")
                else:
                    await ctx.send("You try to pet something, only to realize what you're trying to pet is silly.")
                return
        await ctx.send("You try to pet something, only to realize you can't find what you wanted to pet.") 

    @in_channel(north_woods)
    @commands.command()
    async def rest(self, ctx, args):
        for actor in actors:
            if actor == args:
                if actor == "box":
                    await ctx.send("You rest next to the box. It seems indifferent.")
                elif actor == "trees":
                    await ctx.send("You plop down under the trees and rest in the shade. The wind softly rustles the leaves. Somewhere you can hear water gently flowing. A lone bird chirps cheerfully.")
                elif actor == "path":
                    await ctx.send("You lay down in the middle of the dirt path and rest for a bit. The salesman is looking at you, irritated that you're in his way.")
                else:
                    await ctx.send("You try to rest near something, only to realize what you're trying to rest near is silly.")
                return
        await ctx.send("You try to rest near something, only to realize you can't find what you wanted to rest near.") 

    @in_channel(north_woods)
    @commands.command()
    async def poke(self, ctx, args):
        for actor in actors:
            if actor == args:
                if actor == "box":
                    await ctx.send("You poke the box. It seems indifferent.")
                elif actor == "bush" and "rustling" in actors:
                    await ctx.send("You poke the bush and a dazed and annoyed pixie flutters out of it.")
                elif actor == "pixie":
                    await ctx.send("You poke the pixie, it looks even more annoyed now and begins to flutter away")
                elif actor == "salesmna":
                    await ctx.send("You poke the salesman. He seems mildly annoyed.")
                else:
                    await ctx.send("You try to poke something, only to realize what you're trying to poke is silly.")
                return
        await ctx.send("You try to poke something, only to realize you can't find what you wanted to poke.") 
           


#---------------------------------------------------------------------------------------------------------
#                                End of the action commands block
#---------------------------------------------------------------------------------------------------------

def setup(client):
    client.add_cog(northern_woods(client))