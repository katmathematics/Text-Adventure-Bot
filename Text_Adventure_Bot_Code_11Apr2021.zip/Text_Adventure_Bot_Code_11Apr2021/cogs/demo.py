import discord
import random
from datetime import datetime
from typing import Optional
from discord.ext import commands
from discord import Embed, Member

#Cog for light-hearted demo commands the bot can run
class demo(commands.Cog):

    def __init__(self, bot):
        self.bot = bot
    
    #An example of an event run through a cog
    @commands.Cog.listener()
    async def on_ready(self):
        print('Bot is online...')

    #Writes ping to a chat channel
    @commands.command()
    async def pong(self, ctx):
        await ctx.send("Ping!")

    #Grabs info on a user
    @commands.command()
    async def user_info(self, ctx, target: Optional[Member]):

        embed = Embed(title="User information")

        target = target or ctx.author

        embed = Embed(title = "User information",
                      colour=target.colour,
                      timestamp=datetime.utcnow())
        
        embed.set_thumbnail(url=target.avatar_url)

        fields = [("ID",target.id, False),
                  ("Name", str(target), True),
                  ("Bot?", target.bot, True),
                  ("Top role", target.top_role.mention, True),
                  ("Status", str(target.status).title(), True)]

        for name, value, inline in fields:
                embed.add_field(name=name,value=value,inline=inline)
        
        await ctx.send(embed=embed)

    #Gives a standard 8ball answer to text following "!8ball"
    @commands.command(aliases=["8ball","eightball"])
    async def _8ball(self, ctx, *, question):
        response = ['It is certain.',
                    'As I see it, yes',
                    'Signs point to yes.',
                    'Ask again after I\'ve had my coffee.',
                    'Eh.',
                    'A survey I conducted indicates that will not be the case',
                    'Outlook not so good',
                    'You have better odds of keeping a dragon snake alive.',
                    ]
        await ctx.send(f'Question: {question}\nAnswer: {random.choice(response)}')


    #Mimics any text following the "!lyrebird" in a message
    @commands.command()
    async def lyrebird(self, ctx, *args):
        response = ""
        for arg in args:
            response = response + " " + arg
        await ctx.channel.send(response)



def setup(client):
    client.add_cog(demo(client))